-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2021 at 07:05 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartcut_salon`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_master`
--

CREATE TABLE `admin_master` (
  `id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `fullname` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_master`
--

INSERT INTO `admin_master` (`id`, `user_id`, `fullname`, `gender`, `dob`, `contact`, `email`, `address`, `city`, `state`, `country`, `pincode`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 42, 'Admin', 'Male', '2021-01-15', '7016069007', 'admin@gmail.com', '                                                                                                                        \"Akashar\" , Kalawad Road,                                                                                                              ', 'Rajkot', 'Gujrat', 'India', '360001', NULL, '2021-01-27 14:06:38', '2021-02-22 07:05:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `artist_master`
--

CREATE TABLE `artist_master` (
  `id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `salon_id` int(5) NOT NULL,
  `start` time NOT NULL,
  `end` time NOT NULL,
  `holiday` varchar(10) NOT NULL,
  `fullname` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `artist_master`
--

INSERT INTO `artist_master` (`id`, `user_id`, `salon_id`, `start`, `end`, `holiday`, `fullname`, `gender`, `contact`, `email`, `address`, `city`, `state`, `country`, `pincode`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 41, 1, '08:00:00', '20:00:00', 'saturday', 'Bhavik', 'Male', '9510065166', 'bhavik@gmail.com', '                                                                                Palace Road                                                                                ', 'Rajkot', 'Gujrat', 'India', '360001', NULL, '2021-01-27 14:11:09', '2021-03-09 20:25:34', NULL),
(2, 54, 2, '08:00:00', '20:00:00', 'sunday', 'Janish S. Kalawadiya', 'Male', '8070909712', 'janish@gmail.com', 'Cenal Road,Rajkot', 'Rajkot', 'Gujrat', 'India', '360001', NULL, '2021-02-07 06:16:16', NULL, NULL),
(3, 56, 4, '09:00:00', '20:00:00', 'saturday', 'Vatsal', 'Male', '9033930037', 'vatsal@gmail.com', '150feet Ring Road,', 'Rajkot', 'Gujrat', 'India', '360001', NULL, '2021-02-23 17:16:28', NULL, NULL),
(4, 58, 1, '08:00:00', '20:00:00', 'saturday', 'Jay Dadhaniya', 'Male', '0123456789', 'jay123@gmail.com', 'Rajkot', 'Rajkot', 'Gujrat', 'India', '360001', NULL, '2021-03-02 08:49:02', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

CREATE TABLE `customer_master` (
  `id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `fullname` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`id`, `user_id`, `fullname`, `gender`, `dob`, `contact`, `email`, `city`, `state`, `country`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(8, 47, 'Sagar Mer', 'Male', '2021-01-07', '6353574444', 'sagarmer@gmail.com', 'Rajkot', 'Gujrat', 'India', NULL, '2021-01-28 13:16:28', NULL, NULL),
(9, 51, 'Gaurav Vipani', 'Male', '2021-01-06', '9737493751', 'gaurav@gmail.com', 'Rajkot', 'Gujrat', 'India', NULL, '2021-01-31 03:57:18', NULL, NULL),
(10, 53, 'Darshit Girishbhai Hirani', 'Male', '2000-02-25', '9097087012', 'darshit@gmail.com', 'Rajkot', 'Gujrat', 'India', NULL, '2021-02-05 16:03:25', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `discount_master`
--

CREATE TABLE `discount_master` (
  `id` int(5) NOT NULL,
  `salon_id` int(5) NOT NULL,
  `name` varchar(40) NOT NULL,
  `code` varchar(10) NOT NULL,
  `amount` int(5) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `reservation_master`
--

CREATE TABLE `reservation_master` (
  `id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `salon_id` int(5) NOT NULL,
  `artist_id` int(5) NOT NULL,
  `services_id` int(5) NOT NULL,
  `name` varchar(40) NOT NULL,
  `reserve_date` date NOT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `end_time` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `is_discounted` tinyint(1) DEFAULT NULL,
  `discount_id` int(5) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation_master`
--

INSERT INTO `reservation_master` (`id`, `user_id`, `salon_id`, `artist_id`, `services_id`, `name`, `reserve_date`, `start_time`, `end_time`, `status`, `type`, `is_discounted`, `discount_id`, `created_at`, `deleted_at`) VALUES
(1, 42, 1, 1, 2, 'Kalawdiya Jenish Sanjaybhai', '2021-03-09', NULL, '', 'confirm', 'Admin', NULL, NULL, '2021-02-18 13:28:19', NULL),
(7, 42, 1, 1, 2, 'Vadodariya Jay Ajaybhai', '2021-02-27', NULL, '', 'requested', 'Admin', NULL, NULL, '2021-02-23 13:07:10', NULL),
(8, 42, 1, 1, 2, 'Jay', '2021-02-27', NULL, '', 'requested', 'Admin', NULL, NULL, '2021-02-23 16:27:20', NULL),
(15, 58, 4, 3, 3, 'Ajay', '2021-03-17', '12:30', '13:00', 'requested', 'Admin', NULL, NULL, '2021-03-14 05:19:23', NULL),
(16, 58, 4, 3, 2, 'Jay Vadodariya', '2021-03-17', '13:00', '13:20', 'confirm', 'artist', NULL, NULL, '2021-03-17 05:50:42', NULL),
(18, 41, 1, 1, 2, 'Vipani Gaurav', '2021-05-04', NULL, '', 'confirm', 'Admin', NULL, NULL, '2021-05-04 09:11:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `salon_master`
--

CREATE TABLE `salon_master` (
  `id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `salon_name` varchar(40) NOT NULL,
  `start` time NOT NULL,
  `end` time NOT NULL,
  `holiday` varchar(10) NOT NULL,
  `fullname` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salon_master`
--

INSERT INTO `salon_master` (`id`, `user_id`, `salon_name`, `start`, `end`, `holiday`, `fullname`, `gender`, `contact`, `email`, `address`, `city`, `state`, `country`, `pincode`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 43, 'Rajkamal', '08:00:00', '20:00:00', 'saturday', 'Chirag', 'Male', '9033930035', 'chirag1@gmail.com', '                                                                                                                                                                                                                                                               ', 'Rajkot', 'Gujrat', 'India', '360002', NULL, '2021-01-27 13:56:46', '2021-03-09 20:24:13', NULL),
(2, 50, 'Smartcut', '08:00:00', '20:00:00', 'sunday', 'Bhavik', 'Male', '9427979008', 'bhavik@gmail.com', '150 feet ring road,', 'Rajkot', 'Gujrat', 'India', '360005', NULL, '2021-01-29 17:11:25', NULL, NULL),
(4, 55, 'Alvin Hair Salon', '09:00:00', '20:00:00', 'saturday', 'Divyesh Bhatti', 'Male', '9033930036', 'divyesh@gmail.com', '150feet Ring Road,\r\nOpp-Akashar Heights,', 'Rajkot', 'Gujrat', 'India', '360001', NULL, '2021-02-23 17:14:32', NULL, NULL),
(5, 57, 'Bombay', '09:00:00', '20:30:00', 'no holiday', 'Kevin Gohel', 'Male', '1234567890', 'kevin@gmail.com', 'Palace Road,', 'Rajkot', 'Gujrat', 'India', '360001', NULL, '2021-02-25 15:47:20', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `services_master`
--

CREATE TABLE `services_master` (
  `id` int(5) NOT NULL,
  `salon_id` int(5) NOT NULL,
  `artist_id` int(5) NOT NULL,
  `services_name` varchar(40) NOT NULL,
  `cetegory` varchar(10) NOT NULL,
  `amount` int(5) NOT NULL,
  `persontime` varchar(6) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services_master`
--

INSERT INTO `services_master` (`id`, `salon_id`, `artist_id`, `services_name`, `cetegory`, `amount`, `persontime`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 1, 1, 'Hair Cut', 'Male', 100, '30', '2021-02-10 11:06:44', NULL, NULL),
(3, 4, 3, 'Beard', 'Male', 150, '35', '2021-02-23 17:18:18', NULL, NULL),
(4, 1, 1, 'Beard Settings', 'Male', 70, '20', '2021-03-02 02:34:47', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_master`
--

CREATE TABLE `users_master` (
  `id` int(5) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_master`
--

INSERT INTO `users_master` (`id`, `contact`, `password`, `role`, `created_at`, `deleted_at`) VALUES
(41, '9510065166', '$2y$10$DbSsNPUGzFWoGo.BHXcm5uIfKuv9gHZbtxwd0UuuDtB943MsUXp2y', 'artist', '2021-01-26 09:51:05', NULL),
(42, '7016069007', '$2y$10$DbSsNPUGzFWoGo.BHXcm5uIfKuv9gHZbtxwd0UuuDtB943MsUXp2y', 'admin', '2021-01-26 13:50:48', NULL),
(43, '9033930035', '$2y$10$DbSsNPUGzFWoGo.BHXcm5uIfKuv9gHZbtxwd0UuuDtB943MsUXp2y', 'owner', '2021-01-27 10:35:08', NULL),
(47, '6353574444', 'Sagar@123', 'customer', '2021-01-28 13:16:28', NULL),
(50, '9427979008', '$2y$10$Fj1YmNcVJ6Hae6oVaQEmdeI.LwviYpcvcIjvQvjXj3ypRh27VhjJe', 'owner', '2021-01-29 17:11:25', NULL),
(51, '9737493751', '$2y$10$DbSsNPUGzFWoGo.BHXcm5uIfKuv9gHZbtxwd0UuuDtB943MsUXp2y', 'customer', '2021-01-31 03:57:18', NULL),
(53, '9097087012', '$2y$10$Cp5vHimk03UTXwEx5IPNDOSkYxtCsTL4OI2XEyItR2G9balLTum7i', 'customer', '2021-02-05 16:03:25', NULL),
(54, '8070909712', '$2y$10$RjVdyq5h7Ba3R.9iYn7WqeNDeNrc1Ze69C5G1szZTvh/5vx8qxJpe', 'artist', '2021-02-07 06:16:15', NULL),
(55, '9033930036', '$2y$10$MYfZL.lywme1epfj5h4Ag.P3/N7X/xU0p9jPcpcizvT2NaEKWY3FG', 'owner', '2021-02-23 17:14:32', NULL),
(56, '9033930037', '$2y$10$G1LzOtrVfnzIOsyGwe0owOnaVKYNGggiea/4lbwHP5MiQYo7D64wq', 'artist', '2021-02-23 17:16:28', NULL),
(57, '1234567890', '$2y$10$WVhIPG4qtT5Y9NR4wuUxXOetBbIqG9m/wXo0yf6/wjZeXKBmTb6ji', 'owner', '2021-02-25 15:47:20', NULL),
(58, '0123456789', '$2y$10$Pv6W0xB6x/5HrXziI02s8eUNLqJLKW5voCHbYr8aWKoN3PiCUXnhm', 'artist', '2021-03-02 08:49:01', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_master`
--
ALTER TABLE `admin_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `artist_master`
--
ALTER TABLE `artist_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `salon_id` (`salon_id`);

--
-- Indexes for table `customer_master`
--
ALTER TABLE `customer_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_id_2` (`user_id`);

--
-- Indexes for table `discount_master`
--
ALTER TABLE `discount_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salon_id` (`salon_id`);

--
-- Indexes for table `reservation_master`
--
ALTER TABLE `reservation_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`,`salon_id`,`artist_id`,`services_id`,`discount_id`),
  ADD KEY `salon_id` (`salon_id`),
  ADD KEY `artist_id` (`artist_id`),
  ADD KEY `services_id` (`services_id`),
  ADD KEY `discount_id` (`discount_id`);

--
-- Indexes for table `salon_master`
--
ALTER TABLE `salon_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `services_master`
--
ALTER TABLE `services_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salon_id` (`salon_id`,`artist_id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- Indexes for table `users_master`
--
ALTER TABLE `users_master`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_master`
--
ALTER TABLE `admin_master`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `artist_master`
--
ALTER TABLE `artist_master`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer_master`
--
ALTER TABLE `customer_master`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `reservation_master`
--
ALTER TABLE `reservation_master`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `salon_master`
--
ALTER TABLE `salon_master`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `services_master`
--
ALTER TABLE `services_master`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users_master`
--
ALTER TABLE `users_master`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_master`
--
ALTER TABLE `admin_master`
  ADD CONSTRAINT `admin_master_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_master` (`id`);

--
-- Constraints for table `artist_master`
--
ALTER TABLE `artist_master`
  ADD CONSTRAINT `artist_master_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_master` (`id`),
  ADD CONSTRAINT `artist_master_ibfk_2` FOREIGN KEY (`salon_id`) REFERENCES `salon_master` (`id`);

--
-- Constraints for table `customer_master`
--
ALTER TABLE `customer_master`
  ADD CONSTRAINT `customer_master_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_master` (`id`);

--
-- Constraints for table `discount_master`
--
ALTER TABLE `discount_master`
  ADD CONSTRAINT `discount_master_ibfk_1` FOREIGN KEY (`salon_id`) REFERENCES `salon_master` (`id`);

--
-- Constraints for table `reservation_master`
--
ALTER TABLE `reservation_master`
  ADD CONSTRAINT `reservation_master_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_master` (`id`),
  ADD CONSTRAINT `reservation_master_ibfk_2` FOREIGN KEY (`salon_id`) REFERENCES `salon_master` (`id`),
  ADD CONSTRAINT `reservation_master_ibfk_3` FOREIGN KEY (`artist_id`) REFERENCES `artist_master` (`id`),
  ADD CONSTRAINT `reservation_master_ibfk_4` FOREIGN KEY (`services_id`) REFERENCES `services_master` (`id`),
  ADD CONSTRAINT `reservation_master_ibfk_5` FOREIGN KEY (`discount_id`) REFERENCES `discount_master` (`id`);

--
-- Constraints for table `salon_master`
--
ALTER TABLE `salon_master`
  ADD CONSTRAINT `salon_master_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_master` (`id`);

--
-- Constraints for table `services_master`
--
ALTER TABLE `services_master`
  ADD CONSTRAINT `services_master_ibfk_1` FOREIGN KEY (`salon_id`) REFERENCES `salon_master` (`id`),
  ADD CONSTRAINT `services_master_ibfk_2` FOREIGN KEY (`artist_id`) REFERENCES `artist_master` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
